//-----------------------------------
//Assignment# 1
//Questions# 2
//File name:A1Question2
//Written by: Vickel Leung, 40005344
//For Comp 218 Section EC/Winter 2016
//-----------------------------------

#include <iostream> // for cin, cout

using namespace std;

int main()

{	// Title
	cout << "------------------------------------" "\n"
		 << "Vickel's Distance Converter Program " "\n"
		 << "------------------------------------" << endl;

	// Explanation of the program for users
	cout << "This program will help you convert the distance travelled into meter" "\n"
		 << "Please input the unit of measurement as in km, hm, dm, and m." "\n" 
		 << "I.E: 10 km, 10 hm, 10dm, and 10m will equal to 11110m" << endl;

	// varriable for unit of measurement i.e: k for kilometer
	float k, h, d, m;

	// varriable for user input for unit of measurement
	float km, hm, dm, mt;

	// cin for the user input on the desired conversion
	cin >> hm >> km >> dm >> mt;
	
	//converting unit of measurement to meter eg; km= 1 * 1000
	k = km * 1000; 
	h = hm * 100; 
	d = dm * 10; 
	m = mt; 

	// output for the distance travelled converter with the sum
	cout << "\n" << km << " kilometer is equal to " << k << " m, " << hm << " hectometer is equal to " << h << " m, " 
		 << dm << " decameter is equal to " << d << " m and " << mt << " meter." "\n"
		 << "The sum of all metre is equal to " << k + h + d + m << "m" "\n"
		 << "Thank you for using Vickel's distance converter." << endl;

	return 0;
}