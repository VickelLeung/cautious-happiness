//-----------------------------------
//Assignment# 1
//Question# 1
//File name:A1Question1
//Written by Vickel Leung, 40005344
//For Comp 218 Section EC/Winter 2016
//-----------------------------------


#include <iostream> //for cin, cout

using namespace std;

int main()
{	
	//welcome message and output of COMP218
	cout << "Welcome to \n" << " \n"
		<< "CCCC  OOOO  M   M  PPPP  2222  1  8888 \n"
		<< "C  C  O  O  MM MM  P  P  2  2  1  8  8 \n"
		<< "C  C  O  O  M M M  P  P  2  2  1  8  8 \n"
		<< "C     O  O  M   M  P  P     2  1  8  8 \n"
		<< "C     O  O  M   M  PPPP  2222  1  8888 \n"
		<< "C     O  O  M   M  P     2     1  8  8 \n"
		<< "C  C  O  O  M   M  P     2     1  8  8 \n"
		<< "C  C  O  O  M   M  P     2     1  8  8 \n"
		<< "CCCC  OOOO  M   M  P     2222  1  8888 \n" << endl;

	return 0;
}
