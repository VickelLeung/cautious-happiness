//-----------------------------------
//Assignment# 1
//Questions# 3
//File name:A1Question3
//Written by: Vickel Leung, 40005344
//For Comp 218 Section EC/Winter 2016
//-----------------------------------

#include <iostream> // for cin, cout
#include <string> // for string

using namespace std;

int main()
{	//greeting message and instruction for the user
	cout << "----------------------------" << endl
		<< "	Word Manipulator" << endl
		<< "----------------------------" << endl
		<< "Please Enter a word that correspond to at leash 5letter/characters." << endl;

	//declaring string for manipulator
	string word;
	string firstSwap;

	//user input for word manipulator
	cin >> word;

	//calculating the length of word
	cout << "the length of the word " << word << " is " << word.length() << endl
		<< endl;

	//declaring variable to swap the 1st & 2nd character
	firstSwap = word.substr(1, 1) + word.substr(0, 1);

	//manipulating first part of word
	cout << "The first and second charater of the word " << word << " are " << word.substr(0, 1)
		<< " and " << word.substr(1, 1) << endl
		<< word << " with the first and second character swapped is "
		<< firstSwap + word.substr(2, 20) << endl;	

//declaring variable to swap the 2nd to last & last character
	char secondSwap = word.at(word.length() - 1);
		word.at(word.length() - 1) = word.at(word.length() - 2);
		word.at(word.length() - 2) = secondSwap;

	//manipulating the ending part of the word
	cout << "\n" "The second to last and last characters of the word are "
		 << word.at(word.length() - 1) << " and " << word.at(word.length() - 2) << endl
		 << "with the second to last and last character swapped is" << endl
		 << firstSwap+word.substr(2.10) << endl
		 << "\n" "Thank you for using Vickel's word manipulator program." << endl;

	return 0;
}